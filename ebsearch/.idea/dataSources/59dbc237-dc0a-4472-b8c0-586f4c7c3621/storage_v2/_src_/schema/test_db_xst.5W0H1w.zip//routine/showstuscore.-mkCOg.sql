create
  definer = root@localhost procedure showstuscore()
begin
select * from tb_tb_course_new;
end;

