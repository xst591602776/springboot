create definer = root@localhost trigger sumofsalary
  before INSERT
  on tb_emp6
  for each row
  set @sum=@sum+NEW.salary;

