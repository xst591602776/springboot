create
  definer = root@localhost procedure showstuscore111()
begin select * from tb_course_new; end;

